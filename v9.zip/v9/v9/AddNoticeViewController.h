//
//  AddNoticeViewController.h
//  v9
//
//  Created by Gavin Trebilcock on 5/25/17.
//  Copyright © 2017 Max Newall. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddNoticeViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *noticeText;

@end
