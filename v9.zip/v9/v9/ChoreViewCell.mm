//
//  ChoreViewCell.m
//  v9
//
//  Created by Gavin Trebilcock on 5/24/17.
//  Copyright © 2017 Max Newall. All rights reserved.
//

#import "ChoreViewCell.h"


@implementation ChoreViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
